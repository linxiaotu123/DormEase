<?php
//  防止全局变量造成安全隐患
$login = false;
//  启动会话，这步必不可少
session_start();
//  判断是否登陆
if (isset($_SESSION["login"]) && $_SESSION["login"] === true) {
    echo json_encode('success');
} else {
    //  验证失败，将 $_SESSION["login"] 置为 false
    $_SESSION["login"] = false;
    echo json_encode('fail');
}
?>