<?php
    //引入数据库连接池
    include './db.php';
    //定义SQL
    $sql = "select * from user where state = '3' order by id asc";
    //执行SQL
    $res = $conn->query($sql);
    $arr = array();
    if($res->num_rows>0){
        while($row = $res->fetch_assoc()){
            $arr[] = $row;
        }
        echo json_encode($arr);
        $conn->close();
    }else{
        echo json_encode("fail");
        $conn->close();
    }
?>