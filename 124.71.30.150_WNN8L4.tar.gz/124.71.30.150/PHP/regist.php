<?php
//引入数据库连接池
include './db.php';
//获取变量
$account = $_POST['account'];
$password = $_POST['password'];
$name = $_POST['name'];
$stuid = $_POST['stuid'];
//定义sql语句
$sql1 = "select * from user where account = '{$account}'";
$sql2 = "select * from user where number = '{$stuid}'";
$sql3 = "insert into user (account,password,name,number,state) values ('{$account}','{$password}','{$name}','{$stuid}','3')";

//执行SQL1
$res1 = $conn->query($sql1);

// 验证账号是否重复
if($res1->num_rows>0){
    echo json_encode('accountExist');
    return;
}

// 验证学号是否重复
$res2 = $conn->query($sql2);

if($res2->num_rows>0){
    echo json_encode('stuidExist');
    return;
}

//插入数据
$res3 = $conn->query($sql3);

if($res3 === TRUE){
    echo json_encode('success');
}else{
    echo json_encode('fail');
}

$conn->close();

?>