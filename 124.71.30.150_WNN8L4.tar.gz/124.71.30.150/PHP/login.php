<?php
//引入数据库连接池
include './db.php';
//获取变量
$account = $_POST['account'];
$password = $_POST['password'];
//定义sql语句
$sql = "select state from user where account = '{$account}' and password = '{$password}'";

//执行SQL
$res = $conn->query($sql);

if ($res->num_rows>0) {
    //启动session
    session_start();
    //声明session并且赋值
    $_SESSION['login'] = true;
    $_SESSION['account'] = $account;
    $row = mysqli_fetch_assoc($res);
    if($row['state'] == '1'){
        echo json_encode('admin');
    }else if($row['state'] == '0'){
        echo json_encode('student');
    }else{
        echo json_encode('notApproved');
    }
} else {
    echo json_encode('fail');
}
?>